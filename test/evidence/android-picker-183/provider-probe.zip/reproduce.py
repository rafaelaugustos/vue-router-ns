import subprocess,time,json,datetime
from pathlib import Path
root=Path('/private/tmp/android-picker183');out=root/'provider-probe';out.mkdir(exist_ok=True)
serial='emulator-5586';pkg='org.nativescript.vuerouterns';activity=pkg+'/com.tns.NativeScriptActivity'
def adb(*args):
 return subprocess.check_output(['adb','-s',serial,*args],text=True,timeout=30)
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
adb('install','-r',str(root/'flows-baseline.apk'))
(root/'probe-document.txt').write_text('Native flow acceptance document\n')
adb('push',str(root/'probe-document.txt'),'/sdcard/Download/router-flow-sample.txt')
adb('shell','pm','clear',pkg)
adb('shell','am','start','-W','-n',activity)
end=time.monotonic()+30
while time.monotonic()<end:
 if 'FLOW_READY' in adb('logcat','-d','-v','brief','-s','JS'):break
 time.sleep(.2)
else:raise Exception('App not ready')
adb('shell','am','start','--activity-single-top','-n',activity,'--es','flowCommand','pick')
end=time.monotonic()+45
while time.monotonic()<end:
 adb('shell','uiautomator','dump','/data/local/tmp/probe-ui.xml')
 xml=adb('shell','cat','/data/local/tmp/probe-ui.xml')
 if 'package="com.google.android.documentsui"' in xml:break
 time.sleep(.2)
else:raise Exception('Picker not visible')
adb('logcat','-c')
phases=[]
for phase,path in [('shared1','/sdcard/flow-ui.xml'),('private','/data/local/tmp/probe-ui.xml'),('shared2','/sdcard/flow-ui.xml')]:
 started=stamp();adb('shell','log','-t','FLOW_PROBE',phase+'-start')
 for i in range(5):
  adb('shell','rm','-f',path)
  adb('shell','uiautomator','dump',path)
  xml=adb('shell','cat',path)
  (out/f'{phase}-{i}.xml').write_text(xml)
 adb('shell','log','-t','FLOW_PROBE',phase+'-end')
 phases.append({'phase':phase,'path':path,'dumps':5,'startedAt':started,'endedAt':stamp(),'pickerVisible':'package="com.google.android.documentsui"' in xml})
(out/'system.log').write_text(adb('logcat','-d','-v','threadtime'))
(out/'phases.json').write_text(json.dumps(phases,indent=2)+'\n')
rows=adb('shell','content','query','--uri','content://media/external/file','--projection','_id:_data:mime_type')
(out/'dump-media-rows.txt').write_text('\n'.join(x for x in rows.splitlines() if 'flow-ui.xml' in x or 'probe-ui.xml' in x)+'\n')
(out/'fingerprint.txt').write_text(adb('shell','getprop','ro.build.fingerprint'))
print(json.dumps(phases,indent=2))
