import subprocess as s, pathlib as p, os, time, json, hashlib, signal
root=p.Path('/private/tmp/ios-budget183'); out=root/'local'; out.mkdir(exist_ok=True)
sim='425E50B1-378C-4593-AD77-8B95D1A2DE74'
def command(*args): return s.check_output(args,text=True).strip()
meta={'source':command('git','rev-parse','HEAD'),'initialStatus':command('git','status','--porcelain'),'simulator':sim,'node':command('node','--version'),'xcode':command('xcodebuild','-version'),'startedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
(root/'recording-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
with (root/'recording.log').open('w') as video_log, (out/'runner.log').open('w') as run_log:
    video=s.Popen(['xcrun','simctl','io',sim,'recordVideo','--codec=h264',str(root/'recording.mov')],stdout=video_log,stderr=video_log)
    time.sleep(2)
    assert video.poll() is None, 'Recorder exited early'
    env={**os.environ,'IOS_SIMULATOR':sim,'OUT':str(out),'PATH':'/opt/homebrew/opt/ruby@3.3/bin:/Users/rafaelaugusto/.gem/ruby/3.3.0/bin:'+os.environ['PATH']}
    runner=s.Popen(['node','scripts/native/destinations.mjs','ios'],env=env,stdout=run_log,stderr=run_log)
    prefix=None
    try:
        while runner.poll() is None:
            log=out/'xcodebuild.log'
            if prefix is None and log.exists() and log.stat().st_size:
                prefix=log.read_bytes()
                (out/'xcodebuild-live-prefix.log').write_bytes(prefix)
                meta['liveLog']={'observedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'runnerStillRunning':runner.poll() is None,'prefixBytes':len(prefix),'prefixSHA256':hashlib.sha256(prefix).hexdigest()}
                print('Observed live XCTest output: '+str(meta['liveLog']),flush=True)
            time.sleep(.1)
        meta['runnerExit']=runner.returncode
        if prefix is not None:
            final=(out/'xcodebuild.log').read_bytes()
            meta['liveLog'].update({'finalBytes':len(final),'prefixRetained':final.startswith(prefix)})
        time.sleep(2)
    finally:
        if runner.poll() is None: runner.terminate(); runner.wait(timeout=20)
        video.send_signal(signal.SIGINT)
        meta['recorderExit']=video.wait(timeout=30)
        meta['finishedAt']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
        (root/'recording-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2),flush=True)
raise SystemExit(meta['runnerExit'])
