import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { writeFile } from 'node:fs/promises'
export async function loggedCommand(command, args, { logFile, ...options }) {
  let result
  try { result = await promisify(execFile)(command, args, options) }
  catch (error) {
    await writeFile(logFile, String(error.stdout) + String(error.stderr))
    throw error
  }
  await writeFile(logFile, result.stdout + result.stderr)
}
